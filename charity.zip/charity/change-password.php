<?php include 'include/header.php'; ?>

<div class="dasboadd">
   
<div class="container">
   <div class="row">
      <div class="col-sm-3">
        <?php include 'include/sidebar.php'; ?>
      </div>
      <div class="col-sm-9">
         <div class="right_box">
            <h4 class="hedding_right">Change Password</h4>
            <div class="card_bodym">
               <div class="form-group">
                  <label>Old Password</label>
                  <input type="text" name="" placeholder="Old Password" class="form-control">
               </div>
               <div class="form-group">
                  <label>New Password</label>
                  <input type="text" name="" placeholder="New Password" class="form-control">
               </div>
               <div class="form-group">
                  <label>Confirm Password</label>
                  <input type="text" name="" placeholder="Confirm Password" class="form-control">
               </div>
               <div class="form-group">
                  <label><button class="btn btn_theme btn-lg">Submit</button></label>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php include 'include/footer.php'; ?>