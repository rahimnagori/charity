<?php include 'include/header.php'; ?>

<div class="dasboadd">
   
<div class="container">
   <div class="row">
      <div class="col-sm-3">
        <?php include 'include/sidebar.php'; ?>
      </div>
      <div class="col-sm-9">
         <div class="right_box">
            <h4 class="hedding_right">Account</h4>
            <div class="card_bodym">
               <div class="row">
                  <div class="col-sm-6">
                     <h4>Billing Details </h4>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="" placeholder="Full Name" class="form-control">
                     </div>
                   
                    <div class="form-group">
                        <label>Street</label>
                        <input type="text" name="" placeholder="Street" class="form-control">
                     </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="" placeholder="City" class="form-control">
                     </div>
                    <div class="form-group">
                        <label>State</label>
                        <input type="text" name="" placeholder="State" class="form-control">
                     </div>
                    <div class="form-group">
                        <label>ZIP Code</label>
                        <input type="text" name="" placeholder="ZIP Code" class="form-control">
                     </div>
                    <div class="form-group">
                        <label>Country</label>
                        <input type="text" name="" placeholder="Country" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <h4>Card Details </h4>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="" placeholder="Email" class="form-control">
                     </div>
                      <div class="form-group">
                        <label>Name on the card</label>
                        <input type="text" name="" placeholder="Name on the card" class="form-control">
                     </div>
                      <div class="form-group">
                        <label>Card Number</label>
                        <input type="text" name="" placeholder="Card Number" class="form-control">
                     </div>
                      <div class="form-group">
                        <label>Expiration</label>
                       <div class="row row_sm1">
                          <div class="col-sm-4">
                             <div class="form-group">
                              <select class="form-control">
                                  <option>Month</option>
                                  <option selected value='1'>Janaury</option>
                                  <option value='2'>February</option>
                                  <option value='3'>March</option>
                                  <option value='4'>April</option>
                                  <option value='5'>May</option>
                                  <option value='6'>June</option>
                                  <option value='7'>July</option>
                                  <option value='8'>August</option>
                                  <option value='9'>September</option>
                                  <option value='10'>October</option>
                                  <option value='11'>November</option>
                                  <option value='12'>December</option>
                               </select>
         
                             </div>
                          </div>
                          <div class="col-sm-4">
                             <div class="form-group">
                                <select class="form-control">
          <option>Year</option>
           <option value="2027">2027</option>
           <option value="2026">2026</option>
           <option value="2025">2025</option>
           <option value="2024">2024</option>
           <option value="2023">2023</option>
           <option value="2022">2022</option>
           <option value="2021">2021</option>
           <option value="2020">2020</option>
        </select>
                             </div>
                          </div>
                          <div class="col-sm-4">
                           <div class="form-group">
                              <input type="password" name="" placeholder="CVC" class="form-control">
                           </div>
                          </div>
                       </div>
                     </div>

                  </div>
               </div>
               <div class="form-group">
                  <label><button class="btn btn_theme btn-lg">Submit</button></label>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php include 'include/footer.php'; ?>