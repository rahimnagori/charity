<?php include 'include/header.php'; ?>
<style type="text/css">
   .main_nav .navbar-default{
    background: transparent;
    border: none;
    margin: 0;
    border-radius: 0;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    z-index: 999;
}
.main_nav .navbar-default .navbar-nav > li > a{
   color: #fff;
}
</style>
<div class="banner_top">
   <div class="owl-carousel owl-theme slider_arrrw " id="slider1">
      <?php
  for($i = 0; $i <= 2; $i++){
?>
      <div class="item">
         <div class="banner">
            <img src="img/img_1.png">
           <div class="banter_text">
            <div class="container">
               <div class="row">
               <div class="col-sm-6">
                  <h1>Making <span>the world</span> What is Lorem Ipsum?</h1>
                  <p>
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                  </p>
                  <div class="btn_bot3">
                     <a href="#" class="btn btn_theme2 btn-lg">Sign Up</a>
                  </div>
               </div>
            </div>
            </div>
           </div>
         </div>
      </div>
<?php
  }
?>


   </div>
</div>
<section class="sec1 pad_bottom">
      <div class="container">
         <div class="box_white">
            <div class="row">
            <div class="col-sm-4">
                  <div class="box_icon">
                     <div class="icon_1">
                        <i class="la la-user-plus"></i>
                     </div>
                     <h4>Create Account</h4>
                     <p>
                        
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.
                     </p>
                  </div>
            </div>
            <div class="col-sm-4">
                  <div class="box_icon">
                     <div class="icon_1">
                        <i class="la la-book"></i>
                     </div>
                     <h4>Choose Donation</h4>
                     <p>
                        
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.
                     </p>
                  </div>
            </div>
            
            <div class="col-sm-4">
                  <div class="box_icon">
                     <div class="icon_1">
                        <i class="la la-certificate"></i>
                     </div>
                     <h4>Happ Donut</h4>
                     <p>
                        
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.
                     </p>
                  </div>
            </div>
         </div>
         </div>
      </div>
</section>
<section class="sec2 pad_top">
   <div class="container">
      <div class="headding">
         <h2>Happy Donut People</h2>
         <p>
            
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
         </p>
      </div>
   </div>
   <div class="img_abot">
      <img src="img/about_img.png" class="img_r">
   </div>
</section>
<section class="sec3 pad_sec">
   <div class="container">
      <div class="headding">
         <h2>Our Donations</h2>
         <p>
            
                     Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
         </p>
      </div>
      <div class="slider_corse top_arrow">
         <div class="owl-carousel owl-theme slider_arrrw " id="slider2">
            <?php
  for($i = 0; $i <= 5; $i++){
?>
    
            <div class="item">
               <div class="course_box">
                <a href="details.php"></a>
                  <div class="img_corse">
                     <img src="img/img_2.png">
                     <span>
                        <i class="la la-bookmark"></i> Education
                     </span>
                  </div>
                  <div class="cont_course">
                     <h4>Dummy text of the printing.</h4>
                  <p>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                  </p>
                  <div class="progg_us">
                     <b style="left: 50%;">50%</b>
                     <div class="progg_us2">

                        <span style="width: 50%;"></span>
                     </div>
                  </div>
                  <div class="don_box2">
                  <h6>
                     $25,270
                     <span>Raised</span> 
                  </h6>
                  <h6>
                     $30,000 
                     <span>Goal</span> 
                  </h6>
               </div>
                  </div>
               </div>
            </div>

<?php
  }
?>

         </div>
      </div>
   </div>
</section>
<section class="sec5 pad_sec conter_view">
   <div class="container">
      <div class="don_box1 ">
         <div class="row">
         <div class="col-sm-4">
            <div class="box_icon">
               <div class="icon_1">
                  <i class="la la-book"></i>
               </div>
               <h1><span class="counter" data-count="1000">0</span></h1>
               <h4>Featured
Campaign</h4>
               <p>
                   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text. 
               </p>
               
            </div>
         </div>
         <div class="col-sm-4">
            <div class="box_icon">
               <div class="icon_1">
                  <i class="la la-book"></i>
               </div>
               <h1><span class="counter" data-count="3000">0</span></h1>
               <h4>Dedicated
Volunteers</h4>
<p>
    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text. 
</p>
              
            </div>
         </div>
         <div class="col-sm-4">
            <div class="box_icon">
               <div class="icon_1">
                  <i class="la la-book"></i>
               </div>
               <h1><span class="counter" data-count="8000">0</span></h1>
               <h4>People Helped
Happily</h4>
<p>
    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text. 
</p>
               
            </div>
         </div>
      </div>
         
      </div>

      <div class="headding">
         <h2>Why do we use it?</h2>
         <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
         </p>
      </div>
   </div>
</section>
<section class="sec4 pad_sec">
   <div class="container">
      <div class="row">
         <div class="col-sm-6">
            <div class="img_abot2">
               <img src="img/img_7.png" class="img_r">
            </div>
         </div>
         <div class="col-sm-6">
            <div class="abot_cont">
               <div class="headding">
         <h2>Our Goal is to Help Poor People</h2>
      </div>
      <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.
      </p>
      <div class="ul_segg">
         <ul class="ul_set">
            <li>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                  </li>
            <li>
                      Lorem Ipsum is simply dummy text of the printing 
                  </li>
            <li>
                      Lorem Ipsum is simply dummy text 
                  </li>
            <li>
                     typesetting industry. 
                  </li>
         </ul>
      </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php include 'include/footer.php'; ?>