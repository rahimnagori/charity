<?php include 'include/header.php'; ?>

<div class="dasboadd">
   
<div class="container">
   <div class="row">
      <div class="col-sm-3">
        <?php include 'include/sidebar.php'; ?>
      </div>
      <div class="col-sm-9">
         <div class="right_box">
            <h4 class="hedding_right">Profile</h4>
            <div class="card_bodym">
              <!--  <div class="balance_detail">
                  <div class="box_bl1">
                     <h4>Your Balance</h4>
                     <h1>$8000</h1>
                     <h5>Tip Amount $120</h5>
                  </div>
               </div> -->
               <div class="row">
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="" placeholder="First Name" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="" placeholder="Last Name" class="form-control">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <label>Email</label>
                  <input type="text" name="" placeholder="Email" class="form-control">
               </div>
               <div class="form-group">
                  <label>Phone</label>
                  <input type="text" name="" placeholder="Phone" class="form-control">
               </div>
               
               <div class="form-group">
                  <label><button class="btn btn_theme2 btn-lg">Submit</button></label>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php include 'include/footer.php'; ?>